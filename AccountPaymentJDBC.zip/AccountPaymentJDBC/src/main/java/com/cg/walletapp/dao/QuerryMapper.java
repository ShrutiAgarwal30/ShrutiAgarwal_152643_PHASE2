package com.cg.walletapp.dao;

public class QuerryMapper {
	public static final String INSERT_CUSTOMER ="INSERT INTO WALLETAPP VALUES(?, ?, ?)";
	public static final String GET_CUSTOMER = "SELECT * FROM WALLETAPP WHERE MOBILE = ?";
	public static final String CHECK_MOBILENO = "SELECT * FROM WALLETAPP WHERE MOBILE= ?";
	public static final String UPDATE_BALANCE = "UPDATE WALLETAPP SET BALANCE= ? WHERE MOBILE= ?";
	public static final String INSERT_TRANSACTIONS = "INSERT INTO TRANSACTIONS VALUES(?,?)";
	public static final String PRINT_TRANSACTIONS= "SELECT * FROM TRANSACTIONS WHERE MOBILE=?";
}
